//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: linspace.h
//
// MATLAB Coder version            : 23.2
// C/C++ source code generated on  : 24-Oct-2024 03:49:55
//

#ifndef LINSPACE_H
#define LINSPACE_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace TrajectoryGeneration {
namespace coder {
void linspace(double d2, double n, ::coder::array<double, 2U> &y);

}
} // namespace TrajectoryGeneration

#endif
//
// File trailer for linspace.h
//
// [EOF]
//
